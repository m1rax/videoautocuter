from pathlib import Path
import wave

from .models import Signal


def analyze(wav_path: Path) -> list[Signal]:
    import numpy as np

    features: list[tuple[float, float, float, float]] = []
    with wave.open(str(wav_path), "rb") as wav:
        rate = wav.getframerate()
        size = rate // 2
        window = np.hanning(size)
        frequencies = np.fft.rfftfreq(size, 1 / rate)
        bass = (frequencies >= 45) & (frequencies <= 350)
        audible = frequencies >= 45
        while raw := wav.readframes(size):
            samples = np.frombuffer(raw, dtype="<i2").astype(float) / 32768
            db = 20 * np.log10(max(1e-6, np.sqrt(np.mean(samples ** 2))))
            power = np.abs(np.fft.rfft(samples * window[:len(samples)], n=size)) ** 2
            ratio = power[bass].sum() / max(1e-9, power[audible].sum())
            crest = np.max(np.abs(samples)) / max(1e-6, 10 ** (db / 20))
            features.append((float(db), float(ratio), float(crest), len(samples) / rate))

    events: list[Signal] = []
    group: list[Signal] = []
    levels = [feature[0] for feature in features]
    for i, (db, ratio, crest, length) in enumerate(features):
        baseline = float(np.median(levels[max(0, i - 20):i + 21]))
        rise = db - baseline
        low = ratio >= 0.48 and rise >= 4
        impulse = rise >= 9 and crest >= 3
        if db >= -52 and (low or impulse):
            reason = ("рост энергии в диапазоне 45–350 Гц" if low
                      else "резкий импульс относительно соседних окон")
            group.append(Signal(i * 0.5, i * 0.5 + length,
                                min(1.0, 0.35 + rise / 24), reason,
                                "звуковое событие"))
        elif group:
            events.append(_merge(group))
            group = []
    if group:
        events.append(_merge(group))
    return events


def _merge(group: list[Signal]) -> Signal:
    peak = max(group, key=lambda signal: signal.strength)
    return Signal(group[0].start, group[-1].end, peak.strength,
                  f"{peak.reason}, длительность {group[-1].end - group[0].start:.1f} с",
                  peak.category)

