from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class Signal:
    start: float
    end: float
    strength: float
    reason: str
    category: str = ""

    def to_json(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Word:
    start: float
    end: float
    text: str


@dataclass(frozen=True)
class Phrase:
    start: float
    end: float
    text: str
    words: list[Word]

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> "Phrase":
        return cls(data["start"], data["end"], data["text"],
                   [Word(**word) for word in data["words"]])

