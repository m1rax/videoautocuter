from pathlib import Path
import logging

from .models import Phrase, Word


def transcribe(wav: Path, model_path: Path, language: str | None) -> tuple[str, list[Phrase]]:
    from faster_whisper import WhisperModel

    model = WhisperModel(str(model_path), device="cpu", compute_type="int8",
                         local_files_only=True)
    segments, info = model.transcribe(
        str(wav), language=language, word_timestamps=True, vad_filter=True,
    )
    phrases = []
    next_progress = 0.0
    for segment in segments:
        if segment.end >= next_progress and info.duration:
            logging.getLogger(__name__).info(
                "Распознавание речи: %.0f%%", min(100, segment.end / info.duration * 100),
            )
            next_progress = segment.end + max(1.0, info.duration / 100)
        words = [Word(w.start, w.end, w.word) for w in segment.words or []
                 if w.start is not None and w.end is not None]
        group: list[Word] = []
        for word in words:
            if group and word.start - group[-1].end >= 0.65:
                phrases.append(_phrase(group))
                group = []
            group.append(word)
            if word.text.rstrip().endswith((".", "!", "?", "…")):
                phrases.append(_phrase(group))
                group = []
        if group:
            phrases.append(_phrase(group))
        elif not words and segment.text.strip():
            phrases.append(Phrase(segment.start, segment.end, segment.text.strip(), []))
    return info.language, phrases


def _phrase(words: list[Word]) -> Phrase:
    return Phrase(words[0].start, words[-1].end,
                  "".join(word.text for word in words).strip(), words)

