import subprocess

from .media import MediaError, ffmpeg
from .models import Signal
from pathlib import Path
from tempfile import TemporaryFile


def analyze(source: Path, index: int, duration: float, work_dir: Path) -> tuple[list[float], list[Signal]]:
    import numpy as np

    # Sample in presentation time, including sources with a variable frame rate.
    width, height, fps = 96, 54, 4
    command = ffmpeg(
        "-copyts", "-start_at_zero", "-i", str(source), "-map", f"0:{index}",
        "-vf", f"fps={fps}:start_time=0,scale={width}:{height},format=gray",
        "-f", "rawvideo", "pipe:1",
    )
    cuts: list[float] = []
    motion: list[Signal] = []
    previous = None
    previous_hist = None
    window: list[float] = []
    frame_number = 0
    # Errors go to a temporary file so stderr cannot block the frame reader.
    with TemporaryFile(dir=work_dir) as errors:
        with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=errors) as process:
            assert process.stdout is not None
            while raw := process.stdout.read(width * height):
                if len(raw) != width * height:
                    process.stdout.close()
                    process.wait()
                    raise MediaError("FFmpeg вернул неполный кадр при анализе видео.")
                frame = np.frombuffer(raw, dtype=np.uint8).astype(np.int16)
                hist = np.bincount(frame // 16, minlength=16) / frame.size
                time = frame_number / fps
                if previous is not None:
                    difference = float(np.abs(frame - previous).mean() / 255)
                    shift = float(np.abs(hist - previous_hist).sum() / 2)
                    if difference >= 0.18 and (shift >= 0.22 or difference >= 0.32):
                        if not cuts or time - cuts[-1] >= 0.75:
                            cuts.append(time)
                    else:
                        window.append(difference)
                previous, previous_hist = frame, hist
                frame_number += 1
                if frame_number % (fps * 2) == 0:
                    _record_motion(motion, window, time + 1 / fps, duration)
                    window = []
            if process.wait():
                errors.seek(0)
                raise MediaError(errors.read().decode("utf-8", errors="replace").strip())
    if window:
        _record_motion(motion, window, frame_number / fps, duration)
    return cuts, motion


def _record_motion(
    motion: list[Signal], window: list[float], end: float, duration: float,
) -> None:
    if window and end - 2 < duration:
        average = sum(window) / len(window)
        if average >= 0.045:
            motion.append(Signal(max(0.0, end - 2), min(end, duration),
                                 min(1.0, average / 0.15),
                                 "изменения изображения между склейками"))

