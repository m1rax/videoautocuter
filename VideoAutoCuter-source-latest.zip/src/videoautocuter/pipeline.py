from dataclasses import asdict
import json
import logging
import os
from pathlib import Path
from tempfile import NamedTemporaryFile, TemporaryDirectory
from typing import Any, Callable

from . import audio, scenes, speech
from .media import MediaError, audio_args, digest, probe, run
from .models import Phrase, Signal
from .ranking import rank

LOGGER = logging.getLogger(__name__)
SCHEMA = 1


def save_json(path: Path, data: Any) -> None:
    temporary = None
    try:
        with NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def load_report(path: Path) -> dict[str, Any]:
    report = read_json(path)
    if report.get("schema") != SCHEMA:
        raise MediaError("Версия JSON-отчёта не поддерживается. Повторите анализ.")
    return report


def analyze(
    source: Path, workspace: Path, model: Path | None, language: str | None,
    count: int, weights: dict[str, float], skip_speech: bool,
    profile: str = "auto", subtitle_mode: str = "srt", min_duration: int = 20, max_duration: int = 60,
) -> Path:
    source = source.resolve()
    LOGGER.info("[1/5] Проверка исходника")
    media = probe(source)
    fingerprint = digest(source)
    duration = media["duration"]
    if not 10 <= min_duration <= max_duration <= 120:
        raise MediaError("Длительность клипа должна быть от 10 до 120 секунд, минимум не больше максимума.")
    if duration < min_duration:
        raise MediaError("Исходное видео короче выбранной минимальной длительности клипа.")
    folder = workspace / fingerprint
    folder.mkdir(parents=True, exist_ok=True)
    track = media["audio"]
    if subtitle_mode != "off" and (skip_speech or not track):
        LOGGER.warning("Субтитры не будут созданы без распознанной речи.")
    if track and not skip_speech and (model is None or not all(
        (model / name).is_file() for name in ("model.bin", "config.json", "tokenizer.json")
    )):
        raise MediaError("Укажите через --model папку с model.bin, config.json и tokenizer.json или выберите --skip-speech.")

    def cached(name: str, key: Any, calculate: Callable[[], Any]) -> Any:
        path = folder / f"{name}.json"
        try:
            old = read_json(path)
            if old["key"] == key:
                LOGGER.info("Используется кэш: %s", name)
                return old["data"]
        except (OSError, ValueError, KeyError, TypeError):
            pass
        result = calculate()
        save_json(path, {"key": key, "data": result})
        return result

    with TemporaryDirectory(dir=folder) as temporary:
        work = Path(temporary)
        wav = work / "analysis.wav"

        def prepare_audio() -> Path:
            if not wav.exists():
                run(audio_args(source, track["index"]) + [str(wav)])
            return wav

        LOGGER.info("[2/5] Распознавание речи")
        detected, phrase_data = None, []
        if track and not skip_speech and model is not None:
            model_files = sorted(p for p in model.iterdir() if p.is_file())
            signature = [[p.name, p.stat().st_size, p.stat().st_mtime_ns] for p in model_files]

            def recognize() -> list[Any]:
                detected_language, phrases = speech.transcribe(prepare_audio(), model, language)
                return [detected_language, [asdict(p) for p in phrases]]

            detected, phrase_data = cached("speech", [SCHEMA, signature, language], recognize)

        LOGGER.info("[3/5] Поиск звуковых событий")
        audio_data = cached("audio", SCHEMA, lambda: [
            s.to_json() for s in audio.analyze(prepare_audio())
        ]) if track else []

        LOGGER.info("[4/5] Анализ сцен и движения")

        def scan() -> list[Any]:
            cuts, motion = scenes.analyze(source, media["video"]["index"], duration, work)
            return [cuts, [s.to_json() for s in motion]]

        cuts, motion_data = cached("scenes", SCHEMA, scan)

    LOGGER.info("[5/5] Ранжирование и сохранение отчёта")
    if digest(source) != fingerprint:
        raise MediaError("Исходник изменился во время анализа. Повторите запуск.")
    clips = rank(duration, [Phrase.from_json(p) for p in phrase_data],
                 [Signal(**s) for s in audio_data], cuts,
                 [Signal(**s) for s in motion_data], count, weights, profile, min_duration, max_duration)
    path = folder / "report.json"
    save_json(path, {
        "schema": SCHEMA, "source": str(source), "sha256": fingerprint,
        "media": media, "language": detected, "weights": weights,
        "profile": profile, "subtitle_mode": subtitle_mode, "min_duration": min_duration, "max_duration": max_duration,
        "scene_cuts": cuts, "phrases": phrase_data, "clips": clips,
    })
    return path

