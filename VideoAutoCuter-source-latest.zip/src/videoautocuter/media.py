from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any


class MediaError(RuntimeError):
    pass


def executable(name: str) -> str:
    path = shutil.which(name)
    if path is None:
        raise MediaError(f"Не найден {name}. Добавьте папку bin FFmpeg в PATH.")
    return path


def ffmpeg(*args: str) -> list[str]:
    return [executable("ffmpeg"), "-hide_banner", "-nostdin", "-loglevel", "error", *args]


def run(command: list[str]) -> bytes:
    result = subprocess.run(command, capture_output=True)
    if result.returncode:
        raise MediaError(result.stderr.decode("utf-8", errors="replace").strip())
    return result.stdout


def probe(path: Path) -> dict[str, Any]:
    if not path.is_file() or path.suffix.lower() != ".mp4":
        raise MediaError(f"Укажите существующий файл MP4: {path}")
    data = json.loads(run([
        executable("ffprobe"), "-v", "error", "-show_streams", "-show_format",
        "-of", "json", str(path),
    ]))
    video = next((
        stream for stream in data["streams"]
        if stream["codec_type"] == "video"
        and not stream.get("disposition", {}).get("attached_pic")
    ), None)
    audio = next((s for s in data["streams"] if s["codec_type"] == "audio"), None)
    duration = float(data["format"].get("duration", 0))
    if not video or not 0 < duration < float("inf"):
        raise MediaError("В MP4 нужен видеопоток с известной длительностью.")
    return {"duration": duration, "video": video, "audio": audio}


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def audio_args(source: Path, index: int) -> list[str]:
    # Reset the container origin while preserving the offset between streams.
    return ffmpeg(
        "-copyts", "-start_at_zero", "-i", str(source), "-map", f"0:{index}",
        "-af", "aresample=16000:async=1:first_pts=0", "-ac", "1", "-c:a", "pcm_s16le",
    )

