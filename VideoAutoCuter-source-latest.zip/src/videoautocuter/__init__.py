"""Local automotive highlight analysis."""
