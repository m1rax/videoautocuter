import os
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

from .media import MediaError, digest, ffmpeg
from .models import Phrase, Word


def timestamp(seconds: float, separator: str = ".") -> str:
    whole, ms = divmod(round(seconds * 1000), 1000)
    hours, remainder = divmod(whole, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}{separator}{ms:03d}"


def subtitles(phrases: list[Phrase], start: float, end: float) -> str:
    cues: list[tuple[float, float, str]] = []
    for phrase in phrases:
        if phrase.start >= end or phrase.end <= start:
            continue
        group: list[Word] = []
        for word in phrase.words:
            if not start <= (word.start + word.end) / 2 < end:
                continue
            if group and (word.end - group[0].start > 3.5 or
                          sum(len(w.text) for w in group) + len(word.text) > 44):
                cues.append(_cue(group))
                group = []
            group.append(word)
        if group:
            cues.append(_cue(group))
        elif not phrase.words:
            cues.append((phrase.start, phrase.end, phrase.text))

    blocks: list[str] = []
    cues.sort()
    for i, (a, b, text) in enumerate(cues):
        a, b = max(start, a), min(end, b)
        if i + 1 < len(cues):
            b = min(b, cues[i + 1][0])
        if round((b - start) * 1000) <= round((a - start) * 1000) or not text:
            continue
        blocks.append(f"{len(blocks) + 1}\n{timestamp(a - start, ',')} --> "
                      f"{timestamp(b - start, ',')}\n{text}\n")
    return "\n".join(blocks)


def _cue(words: list[Word]) -> tuple[float, float, str]:
    return words[0].start, words[-1].end, "".join(w.text for w in words).strip()


def subtitle_top(video: dict[str, Any]) -> int:
    width = int(video["width"])
    height = int(video["height"])
    sar = video.get("sample_aspect_ratio", "1:1")
    try:
        numerator, denominator = (int(part) for part in sar.split(":"))
        aspect = width * numerator / (height * denominator)
        if aspect <= 0:
            raise ValueError("invalid aspect ratio")
    except (ValueError, ZeroDivisionError):
        aspect = width / height
    rotation = next((item.get("rotation", 0) for item in video.get("side_data_list", [])
                     if "rotation" in item), video.get("tags", {}).get("rotate", 0))
    if abs(int(rotation)) % 180 == 90:
        aspect = 1 / aspect
    scaled_height = max(2, int(min(1400, 1080 / aspect) / 2) * 2)
    return (1920 + scaled_height) // 2 + 20


def render(
    report: dict[str, Any], ids: list[int], output: Path, burn: bool,
    preview: bool = False, source_override: Path | None = None,
    subtitle_mode: str = "srt",
    subtitle_file: Path | None = None,
) -> list[Path]:
    if subtitle_file is not None and (preview or len(ids) != 1 or subtitle_mode == "off"):
        raise MediaError("Для исправленного SRT укажите один клип и режим srt или burn.")
    edited_text = None
    if subtitle_file is not None:
        edited_text = subtitle_file.read_text(encoding="utf-8-sig")
        if not edited_text.strip():
            raise MediaError("Файл субтитров пуст.")
    source = (source_override or Path(report["source"])).resolve()
    if digest(source) != report["sha256"]:
        raise MediaError("Исходник отличается от файла в отчёте. Повторите анализ.")
    available = {clip["id"]: clip for clip in report["clips"]}
    if any(i not in available for i in ids):
        raise MediaError("Один или несколько ID отсутствуют в отчёте. Проверьте командой list.")
    output = output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    results = []
    media = report["media"]
    phrases = [Phrase.from_json(p) for p in report["phrases"]]
    for i in dict.fromkeys(ids):
        clip = available[i]
        start, end = clip["start"], clip["end"]
        if not 0 <= start < end <= round(media["duration"], 3):
            raise MediaError(f"Недопустимые границы клипа {i}.")
        target = output / f"{'preview' if preview else 'clip'}-{i:02d}.mp4"
        srt = target.with_suffix(".srt")
        if target.exists() or (not preview and srt.exists()):
            raise MediaError(f"Файл уже существует: {target.stem}. Выберите другую папку.")
        with TemporaryDirectory(dir=output) as temporary:
            work = Path(temporary)
            video = work / "render.mp4"
            captions = work / "captions.srt"
            text = (edited_text if edited_text is not None else
                    subtitles(phrases, start, end) if not preview and subtitle_mode != "off" else "")
            if text:
                captions.write_text(text, encoding="utf-8")
            if burn and text and not preview:
                ass = work / "captions.ass"
                conversion = subprocess.run(
                    ffmpeg("-i", str(captions), str(ass)), capture_output=True,
                )
                if conversion.returncode:
                    raise MediaError(conversion.stderr.decode("utf-8", errors="replace").strip())
                lines = ass.read_text(encoding="utf-8-sig").splitlines()
                for index, line in enumerate(lines):
                    if line.startswith("PlayResX:"):
                        lines[index] = "PlayResX: 1080"
                    elif line.startswith("PlayResY:"):
                        lines[index] = "PlayResY: 1920"
                    elif line.startswith("Style: Default,"):
                        fields = line.split(",")
                        fields[1] = "Arial"
                        fields[2] = "42"
                        fields[16] = "2"
                        fields[18] = "8"
                        fields[19] = "60"
                        fields[20] = "60"
                        fields[21] = str(subtitle_top(media["video"]))
                        lines[index] = ",".join(fields)
                ass.write_text("\n".join(lines) + "\n", encoding="utf-8")
            command = ffmpeg(
                "-ss", f"{start:.3f}", "-i", str(source), "-t", f"{end - start:.3f}",
            )
            if preview:
                command += ["-map", f"0:{media['video']['index']}"]
            if media["audio"]:
                command += ["-map", f"0:{media['audio']['index']}", "-c:a", "aac", "-b:a", "192k"]
            if not preview:
                height = 1400 if burn and text else 1920
                filters = (
                    f"[0:{media['video']['index']}]split=2[background][foreground];"
                    "[background]scale=270:480:force_original_aspect_ratio=increase,"
                    "crop=270:480,boxblur=12:2,scale=1080:1920,setsar=1[bg];"
                    f"[foreground]scale=w='max(2,trunc(min(1080,{height}*dar)/2)*2)'"
                    f":h='max(2,trunc(min({height},1080/dar)/2)*2)',setsar=1[fg];"
                    "[bg][fg]overlay=(W-w)/2:(H-h)/2"
                    + (",ass=captions.ass" if burn and text else "") + "[out]"
                )
                command += ["-filter_complex", filters, "-map", "[out]"]
            result = subprocess.run(command + [
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt",
                "yuv420p", "-movflags", "+faststart", str(video),
            ], cwd=work, capture_output=True)
            if result.returncode:
                raise MediaError(result.stderr.decode("utf-8", errors="replace").strip())
            # Publish without replacing an existing file.
            if text:
                _publish(captions, srt)
            try:
                _publish(video, target)
            except (OSError, MediaError):
                if text:
                    srt.unlink()
                raise
        results.append(target)
    return results



def _publish(source: Path, destination: Path) -> None:
    if os.name == "nt":
        source.rename(destination)
        # Files created in TemporaryDirectory inherit its restrictive ACL.
        # Apply the destination folder's permissions after moving the file.
        result = subprocess.run(
            ["icacls", str(destination), "/reset"], capture_output=True,
        )
        if result.returncode:
            destination.unlink(missing_ok=True)
            raise MediaError("Не удалось применить права доступа к экспортированному файлу.")
    else:
        os.link(source, destination)
