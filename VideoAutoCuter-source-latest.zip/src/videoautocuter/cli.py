import argparse
import logging
import math
import os
from pathlib import Path
import sys

from .export import render, timestamp
from .media import MediaError
from .pipeline import analyze, load_report, read_json
from .ranking import WEIGHTS


def positive_int(value: str) -> int:
    try:
        number = int(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("Укажите целое положительное число.") from error
    if number < 1:
        raise argparse.ArgumentTypeError("Укажите целое положительное число.")
    return number


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Локальная нарезка видео")
    commands = parser.add_subparsers(dest="command", required=True)

    scan = commands.add_parser("analyze", help="проанализировать MP4")
    scan.add_argument("source", type=Path)
    scan.add_argument("--workspace", type=Path, default=Path("results"))
    scan.add_argument("--model", type=Path)
    scan.add_argument("--language", choices=("auto", "ru", "en"), default="auto")
    scan.add_argument("--skip-speech", action="store_true")
    scan.add_argument("--count", type=positive_int, default=8, help="число кандидатов")
    scan.add_argument("--profile", choices=("gaming", "auto"), default="gaming")
    scan.add_argument("--subtitles", choices=("off", "srt", "burn"), default="burn",
                      help="субтитры при экспорте: off, srt или burn")
    scan.add_argument("--weights", type=Path, help="JSON с весами критериев")

    listing = commands.add_parser("list", help="показать клипы из отчёта")
    listing.add_argument("report", type=Path)

    for name in ("preview", "export"):
        action = commands.add_parser(name, help="открыть превью" if name == "preview" else "экспортировать клипы")
        action.add_argument("report", type=Path)
        action.add_argument("ids", type=int, nargs=1 if name == "preview" else "*")
        action.add_argument("--output", type=Path)
        action.add_argument("--source", type=Path, help="путь к перемещённому исходнику")
        if name == "export":
            action.add_argument("--top", type=positive_int, help="экспортировать указанное число лучших кандидатов")
            action.add_argument("--subtitles", choices=("off", "srt", "burn"))
            action.add_argument("--subtitle-file", type=Path, help="исправленный SRT для одного клипа")
            action.add_argument("--burn-subtitles", action="store_true")

    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    try:
        if args.command == "analyze":
            weights = read_json(args.weights) if args.weights else WEIGHTS
            if (not isinstance(weights, dict) or weights.keys() != WEIGHTS.keys()
                    or not all(type(v) in (int, float) and math.isfinite(v) and v >= 0
                               for v in weights.values()) or not sum(weights.values())):
                raise MediaError("JSON должен содержать пять неотрицательных весов; хотя бы один больше нуля.")
            path = analyze(args.source, args.workspace.resolve(), args.model,
                           None if args.language == "auto" else args.language,
                           args.count, weights, args.skip_speech, args.profile, args.subtitles)
            print(path)
            return 0
        report = load_report(args.report)
        if args.command == "list":
            print(f"Кандидатов: {len(report['clips'])}")
            for item in report["clips"]:
                print(f"{item['id']:02d}  {timestamp(item['start'])} – "
                      f"{timestamp(item['end'])}  {item['score']:.1f}/100  "
                      + ", ".join(item["categories"]))
                print("    " + "; ".join(item["reasons"]))
            return 0
        preview = args.command == "preview"
        if not preview:
            if args.top is not None and args.ids:
                raise MediaError("Укажите либо ID клипов, либо --top.")
            if args.top is not None:
                if args.top > len(report["clips"]):
                    raise MediaError("В отчёте меньше кандидатов, чем запрошено.")
                args.ids = [item["id"] for item in report["clips"][:args.top]]
            if not args.ids:
                raise MediaError("Укажите ID клипов или --top.")
        mode = getattr(args, "subtitles", None) or report.get("subtitle_mode", "srt")
        if getattr(args, "burn_subtitles", False):
            mode = "burn"
        subtitle_file = getattr(args, "subtitle_file", None)
        if subtitle_file is not None and (len(args.ids) != 1 or mode == "off"):
            raise MediaError("--subtitle-file требует один ID и режим субтитров srt или burn.")
        output = args.output or args.report.parent / ("previews" if preview else "clips")
        if preview and args.output is None:
            from tempfile import mkdtemp
            output.mkdir(parents=True, exist_ok=True)
            output = Path(mkdtemp(prefix="view-", dir=output))
        for path in render(report, args.ids, output,
                           mode == "burn", preview, args.source, mode, subtitle_file):
            print(path)
            if preview and hasattr(os, "startfile"):
                os.startfile(path)
        return 0
    except ImportError as error:
        logging.error("Не удалось загрузить зависимость: %s. См. README.md.", error)
    except (MediaError, OSError, RuntimeError, ValueError, KeyError, TypeError) as error:
        logging.error("Ошибка: %s", error)
    return 1


if __name__ == "__main__":
    sys.exit(main())

