import re
from typing import Any

from .models import Phrase, Signal

WEIGHTS = {
    "content": 30, "audio": 25, "visual": 15, "completeness": 20, "short_form": 10,
}
TOPICS = {
    "звук двигателя": r"перегаз|прострел|звук.{0,14}(мотор|двигател|выхлоп)|exhaust sound|\brev(s|ving)?\b|turbo whistle",
    "разгон и тест-драйв": r"разгон|тест.драйв|заезд|до сотни|acceleration|test drive|zero to sixty|\bpull\b",
    "замеры мощности": r"диностенд|динамометр|лошадин|л[.]?\s*с\.|dyno|horsepower|\bwhp\b",
    "до и после": r"до.{0,25}после|было.{0,30}стало|before.{0,30}after|stock.{0,20}tuned",
    "техническое решение": r"турбин|подвеск|тормоз|прошив|впуск|интеркулер|turbo|suspension|brake|remap|\becu\b",
    "неожиданный результат": r"сломал|поломк|не ожидал|вот это|не завел|blew up|didn.t expect|broke down",
}

GAME_TOPICS = {
    "погоня и полиция": r"\b(?:полици\w*|коп(?:ы|ов|ам|ами|ах)?|мент(?:ы|ов|ам|ами|ах)?|погон\w*|розыск\w*|звёзд[аы]|cops|police|wanted|chase)\b",
    "бой и ограбление": r"ограб|стреля|перестрел|взорва|взрыв|засад|убил|убили|heist|shoot|explosion|ambush",
    "миссия и открытие": r"мисси[яюи]|задани[ея]|пасхалк|секрет|наш[её]л|миссия пройдена|mission|easter egg",
    "авария и трюк": r"авари|разбил|врезал|прыг|прыжок|трюк|crash|stunt|jump",
    "реакция игрока": r"не ожидал|ничего себе|офигеть|обалдеть|что происходит|вот это да|с ума сойти|what the hell|no way|holy",
}


def speech_signals(phrases: list[Phrase], profile: str = "auto") -> list[Signal]:
    topics = GAME_TOPICS if profile == "gaming" else TOPICS
    return [
        Signal(phrase.start, phrase.end, 0.85, phrase.text, category)
        for phrase in phrases
        for category, pattern in topics.items()
        if re.search(pattern, phrase.text, re.IGNORECASE)
    ]


def rank(
    duration: float, phrases: list[Phrase], audio: list[Signal], cuts: list[float],
    motion: list[Signal], limit: int, weights: dict[str, float], profile: str = "auto",
    min_duration: int = 20, max_duration: int = 60,
) -> list[dict[str, Any]]:
    speech = speech_signals(phrases, profile)
    visual = motion + [Signal(t, min(duration, t + 0.25), 0.2, "смена плана")
                       for t in cuts]
    boundaries = sorted({0.0, duration, *cuts,
                         *(p.start for p in phrases), *(p.end for p in phrases),
                         *(a.start for a in audio), *(a.end for a in audio)})
    candidates = []
    for event in speech + audio + visual:
        interval = _window(event, duration, boundaries, phrases, audio, min_duration, max_duration)
        if interval is None:
            continue
        start, end, completeness = interval
        groups = [_strongest(group, start, end) for group in (speech, audio, visual)]
        content, sound, image = groups
        scores = {
            "content": content.strength if content else None,
            "audio": sound.strength if sound else 0.0,
            "visual": image.strength if image else 0.0,
            "completeness": completeness,
            "short_form": max(0.0, 1 - (event.start - start) / 18),
        }
        active = {key: value for key, value in scores.items() if value is not None}
        total = sum(weights[key] for key in active)
        score = sum(weights[key] * value for key, value in active.items()) / total if total else 0.0
        evidence = [item for item in groups if item is not None]
        categories = sorted({item.category for item in evidence if item.category})
        transcript = " ".join(p.text for p in phrases if start <= p.start and p.end <= end)
        candidates.append(({
            "start": round(start, 3), "end": round(end, 3),
            "duration": round(end - start, 3), "score": round(score * 100, 1),
            "scores": scores, "categories": categories or ["визуальная динамика"],
            "reasons": list(dict.fromkeys(item.reason for item in evidence)),
            "transcript": transcript,
        }, sound, content))

    selected: list[dict[str, Any]] = []
    used_audio: set[Signal] = set()
    used_speech: set[Signal] = set()
    for clip, sound, content in sorted(candidates, key=lambda item: (-item[0]["score"], item[0]["start"])):
        if sound is not None and sound in used_audio:
            continue
        if content is not None and content in used_speech:
            continue
        if any(_duplicate(clip, previous) for previous in selected):
            continue
        selected.append({"id": len(selected) + 1, **clip})
        if sound is not None:
            used_audio.add(sound)
        if content is not None:
            used_speech.add(content)
        if len(selected) == limit:
            break
    return selected


def _strongest(signals: list[Signal], start: float, end: float) -> Signal | None:
    return max((s for s in signals if s.start < end and s.end > start),
               key=lambda s: s.strength, default=None)


def _window(
    event: Signal, duration: float, boundaries: list[float],
    phrases: list[Phrase], audio: list[Signal], min_duration: int = 20, max_duration: int = 60,
) -> tuple[float, float, float] | None:
    from bisect import bisect_left, bisect_right

    if duration < min_duration or event.end - event.start > max_duration:
        return None
    desired_start = max(0.0, min(event.start - 3, duration - min_duration))
    desired_end = min(duration, desired_start + max_duration, max(desired_start + max(min_duration, min(28, max_duration)), event.end + 3))
    left = bisect_left(boundaries, max(0.0, event.end - max_duration, desired_start - 12))
    right = bisect_right(boundaries, event.start)
    starts = set(boundaries[left:right]) | {desired_start, max(0.0, event.end - max_duration)}
    left = bisect_left(boundaries, event.end)
    right = bisect_right(boundaries, min(duration, desired_end + 12))
    ends = set(boundaries[left:right]) | {desired_end, min(duration, desired_start + min_duration)}

    nearby = [p for p in phrases if desired_start - 12 < p.end and p.start < desired_end + 12]
    nearby += [a for a in audio if desired_start - 12 < a.end and a.start < desired_end + 12]
    starts = [t for t in starts if t <= event.start and not any(p.start < t < p.end for p in nearby)]
    ends = [t for t in ends if t >= event.end and not any(p.start < t < p.end for p in nearby)]
    options = ((a, b) for a in starts for b in ends if min_duration <= b - a <= max_duration)
    pair = min(options, key=lambda p: (abs(p[0] - desired_start) +
               abs(p[1] - desired_end), p), default=None)
    if pair is None:
        return None
    start, end = pair
    return start, end, 1.0 if start in boundaries and end in boundaries else 0.8


def _duplicate(clip: dict[str, Any], previous: dict[str, Any]) -> bool:
    intersection = min(clip["end"], previous["end"]) - max(clip["start"], previous["start"])
    if intersection >= 0.45 * min(clip["duration"], previous["duration"]):
        return True
    a, b = (set(re.findall(r"\w+", item["transcript"].lower()))
            for item in (clip, previous))
    return min(len(a), len(b)) >= 8 and len(a & b) / len(a | b) >= 0.8

