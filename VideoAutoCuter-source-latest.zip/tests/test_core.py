import json
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory
import unittest

from videoautocuter.export import render, subtitles
from videoautocuter.media import digest, ffmpeg, probe, run
from videoautocuter.models import Phrase, Signal, Word
from videoautocuter.pipeline import analyze, load_report
from videoautocuter.ranking import WEIGHTS, rank, speech_signals
from videoautocuter.cli import main
from unittest.mock import patch


class RankingTests(unittest.TestCase):
    def test_selected_duration_limits(self):
        from videoautocuter.ranking import _window
        event = Signal(130, 132, 0.8, "event")
        for minimum, maximum in ((10, 10), (10, 20), (90, 120), (120, 120)):
            with self.subTest(minimum=minimum, maximum=maximum):
                result = _window(event, 300, [0, 300], [], [], minimum, maximum)
                self.assertIsNotNone(result)
                self.assertTrue(minimum <= result[1] - result[0] <= maximum)

    def test_gaming_profile(self):
        phrase = Phrase(20, 22, "За нами полиция, начинается погоня!", [])
        signals = speech_signals([phrase], "gaming")
        self.assertEqual(signals[0].category, "погоня и полиция")
        self.assertEqual(speech_signals([phrase], "auto"), [])
        apartment = Phrase(24, 25, "Посмотри, какие апартаменты", [])
        self.assertEqual(speech_signals([apartment], "gaming"), [])

    def test_cli_count_and_subtitle_settings(self):
        with patch("videoautocuter.cli.analyze", return_value=Path("report.json")) as analyze:
            self.assertEqual(main(["analyze", "game.mp4", "--count", "15",
                                   "--subtitles", "off"]), 0)
            self.assertEqual(analyze.call_args.args[4], 15)
            self.assertEqual(analyze.call_args.args[-2:], ("gaming", "off"))

    def test_cli_top_selection(self):
        report = {"clips": [{"id": 2}, {"id": 4}, {"id": 9}], "subtitle_mode": "off"}
        with patch("videoautocuter.cli.load_report", return_value=report):
            with patch("videoautocuter.cli.render", return_value=[]) as render:
                self.assertEqual(main(["export", "report.json", "--top", "2"]), 0)
                self.assertEqual(render.call_args.args[1], [2, 4])
                self.assertEqual(render.call_args.args[-2], "off")
    def test_audio_only_and_overlap(self):
        events = [Signal(t, t + 2, 0.9, "low band", "audio")
                  for t in (30, 31, 75, 120, 170, 215)]
        clips = rank(250, [], events, [], [], 8, WEIGHTS)
        self.assertEqual(len(clips), 5)
        for clip in clips:
            self.assertIn("audio", clip["categories"])
            self.assertTrue(20 <= clip["duration"] <= 60)
            self.assertTrue(0 <= clip["start"] < clip["end"] <= 250)

    def test_does_not_cut_phrase(self):
        phrase = Phrase(20, 35, "Сделали замер на диностенде.", [])
        clips = rank(70, [phrase], [], [30], [], 5, WEIGHTS)
        self.assertTrue(clips)
        for clip in clips:
            self.assertFalse(20 < clip["start"] < 35)
            self.assertFalse(20 < clip["end"] < 35)


class SubtitleTests(unittest.TestCase):
    def test_shift_and_clip(self):
        phrase = Phrase(9.5, 12, "Привет мир!", [
            Word(9.5, 10.8, " Привет"), Word(10.8, 12, " мир!"),
        ])
        content = subtitles([phrase], 10, 11.8)
        self.assertIn("00:00:00,000 --> 00:00:01,800", content)
        self.assertIn("Привет мир!", content)
        self.assertEqual(subtitles([phrase], 14, 40), "")


HAS_MEDIA = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


@unittest.skipUnless(HAS_MEDIA, "FFmpeg и FFprobe недоступны")
class MediaTests(unittest.TestCase):
    def test_synthetic_pipeline_and_export(self):
        import numpy

        with TemporaryDirectory(dir=Path.cwd()) as temp:
            folder = Path(temp)
            source = folder / "test.mp4"
            run(ffmpeg(
                "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=12",
                "-f", "lavfi", "-i",
                "aevalsrc=0.5*sin(2*PI*95*t)*between(t\\,10\\,14):s=16000",
                "-t", "35", "-c:v", "libx264", "-c:a", "aac", str(source),
            ))
            before = digest(source)
            path = analyze(source, folder / "cache", None, None, 5, WEIGHTS, True)
            report = load_report(path)
            self.assertTrue(report["clips"])
            self.assertIn("звуковое событие", report["clips"][0]["categories"])
            cache = path.parent / "audio.json"
            modified = cache.stat().st_mtime_ns
            self.assertEqual(analyze(source, folder / "cache", None, None, 5, WEIGHTS, True), path)
            self.assertEqual(cache.stat().st_mtime_ns, modified)
            clip = report["clips"][0]
            report["phrases"] = [{
                "start": clip["start"] + 1, "end": clip["start"] + 2,
                "text": "Проверка", "words": [],
            }]
            target, = render(report, [clip["id"]], folder / "output", False)
            metadata = probe(target)
            self.assertEqual((metadata["video"]["width"], metadata["video"]["height"]),
                             (1080, 1920))
            self.assertIsNotNone(metadata["audio"])
            self.assertAlmostEqual(metadata["duration"], clip["duration"], delta=0.15)
            self.assertIn("00:00:01,000 --> 00:00:02,000",
                          target.with_suffix(".srt").read_text(encoding="utf-8"))
            no_subtitle, = render(report, [clip["id"]], folder / "without-subs",
                                  False, subtitle_mode="off")
            self.assertFalse(no_subtitle.with_suffix(".srt").exists())
            edited = folder / "edited.srt"
            edited.write_text("1\n00:00:01,000 --> 00:00:02,000\nИсправленный текст\n", encoding="utf-8")
            corrected, = render(report, [clip["id"]], folder / "corrected",
                                True, subtitle_mode="burn", subtitle_file=edited)
            self.assertEqual(corrected.with_suffix(".srt").read_text(encoding="utf-8"),
                             edited.read_text(encoding="utf-8"))
            self.assertEqual(digest(source), before)

