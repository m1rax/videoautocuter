import importlib.util
import json
import os
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

HAS_GUI = importlib.util.find_spec("PySide6") is not None
HAS_MEDIA = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


@unittest.skipUnless(HAS_GUI and HAS_MEDIA, "Нужны PySide6, FFmpeg и FFprobe")
class WindowTests(unittest.TestCase):
    def test_edit_and_export_selected_clip(self):
        from PySide6.QtCore import QEventLoop, QTimer, Qt
        from PySide6.QtWidgets import QApplication, QMessageBox
        from videoautocuter.gui import MainWindow
        from videoautocuter.media import digest, ffmpeg, probe, run

        app = QApplication.instance() or QApplication([])
        with TemporaryDirectory(dir=Path.cwd()) as temporary:
            folder = Path(temporary)
            source = folder / "source.mp4"
            run(ffmpeg(
                "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=5",
                "-f", "lavfi", "-i", "anullsrc=channel_layout=mono:sample_rate=16000",
                "-t", "21", "-c:v", "libx264", "-c:a", "aac", str(source),
            ))
            report = {
                "schema": 1, "source": str(source), "sha256": digest(source),
                "media": probe(source), "subtitle_mode": "burn",
                "phrases": [{"start": 1, "end": 2, "text": "Оригинал", "words": []}],
                "clips": [{"id": 1, "start": 0, "end": 20, "score": 90,
                           "categories": ["событие"], "reasons": ["проверка"]}],
            }
            report_path = folder / "report.json"
            report_path.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
            window = MainWindow()
            window.show_report(report_path)
            self.assertEqual(window.clips.count(), 1)
            window.clips.item(0).setCheckState(Qt.CheckState.Checked)
            self.assertIn("Оригинал", window.editor.toPlainText())
            window.editor.setPlainText("1\n00:00:01,000 --> 00:00:02,000\nИсправлено\n")
            window.output.setText(str(folder / "export"))
            with patch.object(QMessageBox, "information"), patch.object(QMessageBox, "critical") as error:
                window.start_export()
                loop = QEventLoop()
                window.worker.finished.connect(loop.quit)
                QTimer.singleShot(60000, loop.quit)
                loop.exec()
                app.processEvents()
                self.assertFalse(window.worker.isRunning())
                error.assert_not_called()
            self.assertTrue((folder / "export" / "clip-01.mp4").is_file())
            text = (folder / "export" / "clip-01.srt").read_text(encoding="utf-8")
            self.assertIn("Исправлено", text)
            self.assertFalse(window.edited_ids)
            window.close()
