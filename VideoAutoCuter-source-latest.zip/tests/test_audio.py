import math
from pathlib import Path
import struct
from tempfile import TemporaryDirectory
import unittest
import wave

from videoautocuter.audio import analyze


class AudioTests(unittest.TestCase):
    def test_finds_low_frequency_event_in_wav_without_speech(self):
        rate = 16000
        silence = bytes(2 * rate * 5)
        tone = b"".join(
            struct.pack("<h", round(12000 * math.sin(2 * math.pi * 95 * i / rate)))
            for i in range(rate * 2)
        )
        with TemporaryDirectory(dir=Path.cwd()) as directory:
            path = Path(directory) / "audio.wav"
            with wave.open(str(path), "wb") as wav:
                wav.setparams((1, 2, rate, 0, "NONE", "not compressed"))
                wav.writeframes(silence + tone + silence)
            events = analyze(path)

        self.assertEqual(len(events), 1)
        self.assertEqual((events[0].start, events[0].end), (5.0, 7.0))
        self.assertIn("45–350 Гц", events[0].reason)

