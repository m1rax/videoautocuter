[Setup]
AppId={{CD3B8D6D-0AF3-4A87-B227-E7B9C02E2311}
AppName=VideoAutoCuter
AppVersion=0.1.0
DefaultDirName={localappdata}\Programs\VideoAutoCuter
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\dist
OutputBaseFilename=VideoAutoCuter-Setup
Compression=lzma2/fast
SolidCompression=yes
WizardStyle=modern
[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
[Files]
Source: "..\dist\VideoAutoCuter\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\models\small\*"; DestDir: "{app}\models\small"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: ".cache\*"
Source: "..\.tools\bin\ffmpeg.exe"; DestDir: "{app}\.tools\bin"; Flags: ignoreversion
Source: "..\.tools\bin\ffprobe.exe"; DestDir: "{app}\.tools\bin"; Flags: ignoreversion
[Icons]
Name: "{autoprograms}\VideoAutoCuter"; Filename: "{app}\VideoAutoCuter.exe"
Name: "{autodesktop}\VideoAutoCuter"; Filename: "{app}\VideoAutoCuter.exe"
[Run]
Filename: "{app}\VideoAutoCuter.exe"; Description: "Запустить VideoAutoCuter"; Flags: nowait postinstall skipifsilent
