from __future__ import annotations

import logging
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable

from PySide6.QtCore import Qt, QThread, QUrl, Signal
from PySide6.QtGui import QCloseEvent, QFont
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QApplication, QAbstractItemView, QComboBox, QFileDialog, QFrame, QHBoxLayout,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMessageBox,
    QPlainTextEdit, QProgressBar, QPushButton, QSlider, QSpinBox, QSplitter,
    QVBoxLayout, QWidget,
)

from .export import render, subtitles, timestamp
from .models import Phrase
from .pipeline import analyze, load_report
from .ranking import WEIGHTS


PROJECT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parents[2]
RESULTS = (Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "VideoAutoCuter" / "results"
           if getattr(sys, "frozen", False) else PROJECT / "results")


class LogHandler(logging.Handler):
    def __init__(self, emit_message: Callable[[str], None]) -> None:
        super().__init__()
        self.emit_message = emit_message

    def emit(self, record: logging.LogRecord) -> None:
        self.emit_message(record.getMessage())


class Worker(QThread):
    message = Signal(str)
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, task: Callable[[Callable[[str], None]], Any]) -> None:
        super().__init__()
        self.task = task

    def run(self) -> None:
        handler = LogHandler(self.message.emit)
        root = logging.getLogger()
        old_level = root.level
        root.setLevel(logging.INFO)
        root.addHandler(handler)
        try:
            self.completed.emit(self.task(self.message.emit))
        except Exception as error:
            self.failed.emit(str(error) or type(error).__name__)
        finally:
            root.removeHandler(handler)
            root.setLevel(old_level)


STYLE = """
QMainWindow, QWidget { background: #11151b; color: #e9edf2; font-size: 13px; }
QFrame#panel { background: #1a2029; border: 1px solid #303946; border-radius: 12px; }
QLabel { background: transparent; }
QLabel#title { font-size: 24px; font-weight: 700; color: #f6f8fa; }
QLabel#heading { font-size: 16px; font-weight: 700; color: #f6f8fa; }
QLabel#muted { color: #a7b2c1; }
QLineEdit, QComboBox, QSpinBox, QPlainTextEdit, QListWidget {
    background: #12171e; border: 1px solid #3a4554; border-radius: 6px;
    padding: 7px; selection-background-color: #89541b; color: #edf1f5;
}
QListWidget::item { padding: 8px 4px; border-bottom: 1px solid #27303b; }
QListWidget::item:selected { background: #343029; color: white; }
QListWidget::indicator { width: 15px; height: 15px; border: 1px solid #8391a3; border-radius: 3px; }
QListWidget::indicator:checked { background: #ed9a37; border-color: #ed9a37; }
QPushButton { background: #303b49; border: none; border-radius: 6px; padding: 9px 14px; font-weight: 600; }
QPushButton:hover { background: #415064; }
QPushButton:disabled { color: #7b8591; background: #272d35; }
QPushButton#primary { background: #ed9a37; color: #17120c; }
QPushButton#primary:hover { background: #ffb657; }
QPushButton#primary:disabled { background: #6d5b43; color: #b5a99a; }
QProgressBar { background: #11171e; border: none; border-radius: 4px; height: 7px; }
QProgressBar::chunk { background: #ed9a37; border-radius: 4px; }
QSplitter::handle { background: #11151b; width: 8px; }
"""


def panel(title: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("panel")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(10, 10, 10, 10)
    layout.setSpacing(5)
    label = QLabel(title)
    label.setObjectName("heading")
    layout.addWidget(label)
    return frame, layout


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("VideoAutoCuter")
        self.resize(1380, 880)
        self.setMinimumSize(980, 680)
        self.report: dict[str, Any] | None = None
        self.report_path: Path | None = None
        self.worker: Worker | None = None
        self.current_id: int | None = None
        self.drafts: dict[int, str] = {}
        self.edited_ids: set[int] = set()
        self.loading_editor = False
        self.preview_end = 0
        self.pending_start: int | None = None

        self.player = QMediaPlayer(self)
        self.audio_output = QAudioOutput(self)
        self.audio_output.setVolume(0.8)
        self.player.setAudioOutput(self.audio_output)
        self.player.positionChanged.connect(self.on_position)
        self.player.mediaStatusChanged.connect(self.on_media_status)
        self.player.playbackStateChanged.connect(self.playback_changed)
        self.player.errorOccurred.connect(self.on_player_error)

        central = QWidget()
        self.setCentralWidget(central)
        main = QVBoxLayout(central)
        main.setContentsMargins(12, 10, 12, 10)
        main.setSpacing(8)
        header = QHBoxLayout()
        title = QLabel("VideoAutoCuter")
        title.setObjectName("title")
        header.addWidget(title)
        subtitle = QLabel("Нарезка игровых видео")
        subtitle.setObjectName("muted")
        header.addWidget(subtitle)
        header.addStretch()
        self.history = QComboBox()
        self.history.setMinimumWidth(220)
        self.history.activated.connect(self.open_history)
        header.addWidget(self.history)
        self.open_report_button = QPushButton("Открыть отчёт")
        self.open_report_button.clicked.connect(self.open_report)
        header.addWidget(self.open_report_button)
        main.addLayout(header)

        input_frame, input_layout = panel("Исходное видео")
        path_row = QHBoxLayout()
        self.source = QLineEdit()
        self.source.setPlaceholderText("Выберите файл MP4")
        self.source.setReadOnly(True)
        self.browse_button = QPushButton("Выбрать видео")
        self.browse_button.clicked.connect(self.choose_source)
        path_row.addWidget(self.source, 1)
        path_row.addWidget(self.browse_button)
        input_layout.addLayout(path_row)

        settings = QHBoxLayout()
        settings.addWidget(QLabel("Кандидатов"))
        self.count = QSpinBox()
        self.count.setRange(1, 1000)
        self.count.setValue(8)
        settings.addWidget(self.count)
        settings.addSpacing(12)
        settings.addWidget(QLabel("Субтитры"))
        self.subtitle_mode = QComboBox()
        self.subtitle_mode.addItem("Вшить в видео", "burn")
        self.subtitle_mode.addItem("Отдельный SRT", "srt")
        self.subtitle_mode.addItem("Без субтитров", "off")
        settings.addWidget(self.subtitle_mode)
        settings.addSpacing(12)
        settings.addWidget(QLabel("Язык"))
        self.language = QComboBox()
        self.language.addItem("Авто", None)
        self.language.addItem("Русский", "ru")
        self.language.addItem("Английский", "en")
        settings.addWidget(self.language)
        settings.addStretch()
        self.analyze_button = QPushButton("Найти моменты")
        self.analyze_button.setObjectName("primary")
        self.analyze_button.clicked.connect(self.start_analysis)
        settings.addWidget(self.analyze_button)
        input_layout.addLayout(settings)
        main.addWidget(input_frame)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        list_frame, list_layout = panel("Найденные моменты")
        self.list_hint = QLabel("Отметьте фрагменты для экспорта")
        self.list_hint.setObjectName("muted")
        list_layout.addWidget(self.list_hint)
        self.select_all_button = QPushButton("Выбрать все")
        self.select_all_button.clicked.connect(self.select_all_clips)
        list_layout.addWidget(self.select_all_button)
        self.clips = QListWidget()
        self.clips.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.clips.currentItemChanged.connect(self.select_clip)
        self.clips.itemDoubleClicked.connect(lambda _item: self.play_clip())
        list_layout.addWidget(self.clips, 1)
        splitter.addWidget(list_frame)

        detail_frame, detail_layout = panel("Просмотр и субтитры")
        self.detail = QLabel("Выберите фрагмент из списка")
        self.detail.setObjectName("muted")
        self.detail.setWordWrap(True)
        detail_layout.addWidget(self.detail)
        playback = QHBoxLayout()
        controls_widget = QWidget()
        controls_widget.setMinimumHeight(165)
        controls = QVBoxLayout(controls_widget)
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(4)
        self.previous_button = QPushButton("◀ Предыдущий")
        self.previous_button.clicked.connect(lambda: self.change_clip(-1))
        self.play_button = QPushButton("▶ Воспроизвести")
        self.play_button.clicked.connect(self.toggle_playback)
        self.next_button = QPushButton("Следующий ▶")
        self.next_button.clicked.connect(lambda: self.change_clip(1))
        for button in (self.previous_button, self.play_button, self.next_button):
            button.setMinimumHeight(32)
        self.seek = QSlider(Qt.Orientation.Horizontal)
        self.seek.sliderMoved.connect(self.seek_clip)
        self.position_label = QLabel("00:00 / 00:00")
        controls.addWidget(self.previous_button)
        controls.addWidget(self.play_button)
        controls.addWidget(self.next_button)
        controls.addWidget(self.seek)
        controls.addWidget(self.position_label)
        controls.addStretch()
        playback.addWidget(controls_widget)
        self.video = QVideoWidget()
        self.video.setMinimumSize(160, 165)
        self.player.setVideoOutput(self.video)
        playback.addWidget(self.video, 1)
        detail_layout.addLayout(playback, 3)
        edit_row = QHBoxLayout()
        edit_row.addWidget(QLabel("Текст и время субтитров"))
        edit_row.addStretch()
        self.open_srt_button = QPushButton("Открыть SRT")
        self.open_srt_button.clicked.connect(self.open_subtitles)
        edit_row.addWidget(self.open_srt_button)
        detail_layout.addLayout(edit_row)
        edit_hint = QLabel("Исправьте текст в строках SRT. Правки сохраняются при экспорте клипа.")
        edit_hint.setObjectName("muted")
        detail_layout.addWidget(edit_hint)
        self.editor = QPlainTextEdit()
        self.editor.setMinimumHeight(60)
        self.editor.setPlaceholderText("Для этого фрагмента субтитры не найдены")
        self.editor.textChanged.connect(self.editor_changed)
        detail_layout.addWidget(self.editor, 2)
        splitter.addWidget(detail_frame)
        splitter.setStretchFactor(0, 2)
        splitter.setStretchFactor(1, 3)
        main.addWidget(splitter, 1)

        export_frame, export_layout = panel("Экспорт")
        export_row = QHBoxLayout()
        self.output = QLineEdit(str(RESULTS / "exports"))
        self.output.setReadOnly(True)
        self.output_button = QPushButton("Папка…")
        self.output_button.clicked.connect(self.choose_output)
        self.export_button = QPushButton("Экспортировать выбранные")
        self.export_button.setObjectName("primary")
        self.export_button.clicked.connect(self.start_export)
        export_row.addWidget(self.output, 1)
        export_row.addWidget(self.output_button)
        export_row.addWidget(self.export_button)
        export_layout.addLayout(export_row)
        self.status = QLabel("Выберите видео или откройте сохранённый отчёт")
        self.status.setObjectName("muted")
        self.status.setWordWrap(True)
        export_layout.addWidget(self.status)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        export_layout.addWidget(self.progress)
        main.addWidget(export_frame)
        self.refresh_history()
        self.update_controls(False)

    def refresh_history(self) -> None:
        self.history.clear()
        self.history.addItem("История обработок", None)
        if not RESULTS.is_dir():
            return
        paths = sorted(RESULTS.glob("*/report.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        for path in paths:
            try:
                report = load_report(path)
                self.history.addItem(Path(report["source"]).name, str(path))
                self.history.setItemData(self.history.count() - 1, report["source"], Qt.ItemDataRole.ToolTipRole)
            except (OSError, ValueError, KeyError, TypeError):
                continue

    def open_history(self, index: int) -> None:
        path = self.history.itemData(index)
        self.history.setCurrentIndex(0)
        if not path or not self.confirm_discard():
            return
        try:
            self.show_report(Path(path))
        except (OSError, ValueError, KeyError, TypeError) as error:
            QMessageBox.critical(self, "Не удалось открыть отчёт", str(error))

    def select_all_clips(self) -> None:
        for index in range(self.clips.count()):
            self.clips.item(index).setCheckState(Qt.CheckState.Checked)

    def choose_source(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(self, "Выберите видео", str(Path.home() / "Downloads"), "Видео MP4 (*.mp4)")
        if filename:
            if not self.confirm_discard():
                return
            self.player.stop()
            self.report = None
            self.report_path = None
            self.current_id = None
            self.drafts.clear()
            self.edited_ids.clear()
            self.clips.clear()
            self.loading_editor = True
            self.editor.clear()
            self.loading_editor = False
            self.detail.setText("Выберите фрагмент из списка")
            self.source.setText(filename)
            self.status.setText("Видео выбрано. Нажмите «Найти моменты».")
            self.update_controls(False)

    def choose_output(self) -> None:
        directory = QFileDialog.getExistingDirectory(self, "Папка для клипов", self.output.text())
        if directory:
            self.output.setText(directory)

    def open_report(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(self, "Открыть отчёт", str(RESULTS), "Отчёты JSON (*.json)")
        if not filename:
            return
        if not self.confirm_discard():
            return
        try:
            self.show_report(Path(filename))
        except (OSError, ValueError, KeyError, TypeError) as error:
            QMessageBox.critical(self, "Не удалось открыть отчёт", str(error))

    def start_analysis(self) -> None:
        if not self.source.text():
            QMessageBox.information(self, "Выберите видео", "Укажите MP4 для анализа.")
            return
        if not self.confirm_discard():
            return
        source = Path(self.source.text())
        count = self.count.value()
        language = self.language.currentData()
        mode = self.subtitle_mode.currentData()
        model = PROJECT / "models" / "small"
        self.player.stop()
        self.run_task(lambda emit: analyze(source, RESULTS, model, language,
                                          count, WEIGHTS, False, "gaming", mode),
                      self.analysis_complete, "Анализируем видео")

    def analysis_complete(self, path: Path) -> None:
        try:
            self.refresh_history()
            self.show_report(path)
        except (OSError, ValueError, KeyError, TypeError) as error:
            QMessageBox.critical(self, "Не удалось открыть отчёт", str(error))

    def show_report(self, path: Path) -> None:
        report = load_report(path)
        if not isinstance(report.get("clips"), list) or not isinstance(report.get("phrases"), list):
            raise ValueError("В отчёте отсутствуют список фрагментов или транскрипция.")
        self.player.stop()
        self.report = report
        self.report_path = path
        self.source.setText(report["source"])
        index = self.subtitle_mode.findData(report.get("subtitle_mode", "srt"))
        if index >= 0:
            self.subtitle_mode.setCurrentIndex(index)
        self.current_id = None
        self.drafts.clear()
        self.edited_ids.clear()
        self.clips.clear()
        for clip in report["clips"]:
            text = (f"{clip['id']:02d}   {timestamp(clip['start'])} – {timestamp(clip['end'])}\n"
                    f"{clip['score']:.0f} / 100   ·   {', '.join(clip['categories'])}")
            item = QListWidgetItem(text)
            item.setData(Qt.ItemDataRole.UserRole, clip["id"])
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            self.clips.addItem(item)
        if self.clips.count():
            self.clips.setCurrentRow(0)
        else:
            self.detail.setText("Подходящие фрагменты не найдены")
            self.loading_editor = True
            self.editor.clear()
            self.loading_editor = False
        self.status.setText(f"Найдено фрагментов: {self.clips.count()} · {path}")
        self.update_controls(False)

    def get_clip(self, clip_id: int) -> dict[str, Any]:
        assert self.report is not None
        return next(clip for clip in self.report["clips"] if clip["id"] == clip_id)

    def select_clip(self, current: QListWidgetItem | None, previous: QListWidgetItem | None) -> None:
        self.player.stop()
        self.preview_end = 0
        self.pending_start = None
        self.playback_changed(self.player.playbackState())
        if current is None or self.report is None:
            return
        self.current_id = current.data(Qt.ItemDataRole.UserRole)
        clip = self.get_clip(self.current_id)
        self.detail.setText(" · ".join(clip["reasons"]))
        if self.current_id not in self.drafts:
            phrases = [Phrase.from_json(p) for p in self.report["phrases"]]
            self.drafts[self.current_id] = subtitles(phrases, clip["start"], clip["end"])
        self.loading_editor = True
        self.editor.setPlainText(self.drafts[self.current_id])
        self.loading_editor = False
        self.seek.setRange(0, round((clip["end"] - clip["start"]) * 1000))
        self.seek.setValue(0)
        self.update_position(0, self.seek.maximum())
        self.update_controls(False)

    def editor_changed(self) -> None:
        if not self.loading_editor and self.current_id is not None:
            self.drafts[self.current_id] = self.editor.toPlainText()
            self.edited_ids.add(self.current_id)

    def open_subtitles(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self, "Открыть субтитры выбранного клипа", self.output.text(), "Субтитры SRT (*.srt)",
        )
        if filename:
            try:
                self.editor.setPlainText(Path(filename).read_text(encoding="utf-8-sig"))
            except (OSError, UnicodeError) as error:
                QMessageBox.critical(self, "Не удалось открыть субтитры", str(error))

    def play_clip(self) -> None:
        if self.current_id is None or self.report is None:
            return
        source = Path(self.report["source"])
        if not source.is_file():
            QMessageBox.warning(self, "Видео не найдено", "Исходный файл перемещён или недоступен.")
            return
        clip = self.get_clip(self.current_id)
        self.preview_end = round(clip["end"] * 1000)
        start = round(clip["start"] * 1000)
        url = QUrl.fromLocalFile(str(source.resolve()))
        if self.player.source() != url:
            self.pending_start = start
            self.player.setSource(url)
        else:
            self.player.setPosition(start)
            self.player.play()

    def toggle_playback(self) -> None:
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        elif self.current_id is not None and self.preview_end and self.player.source().isLocalFile():
            self.player.play()
        else:
            self.play_clip()

    def playback_changed(self, state: QMediaPlayer.PlaybackState) -> None:
        if not hasattr(self, "play_button"):
            return
        self.play_button.setText("❚❚ Пауза" if state == QMediaPlayer.PlaybackState.PlayingState
                                 else "▶ Продолжить" if self.preview_end else "▶ Воспроизвести")

    def change_clip(self, direction: int) -> None:
        row = self.clips.currentRow() + direction
        if 0 <= row < self.clips.count():
            self.clips.setCurrentRow(row)
            self.play_clip()

    def on_media_status(self, status: QMediaPlayer.MediaStatus) -> None:
        if self.pending_start is not None and status in (
            QMediaPlayer.MediaStatus.LoadedMedia, QMediaPlayer.MediaStatus.BufferedMedia,
        ):
            self.player.setPosition(self.pending_start)
            self.pending_start = None
            self.player.play()

    def seek_clip(self, position: int) -> None:
        if self.current_id is not None:
            start = self.get_clip(self.current_id)["start"]
            self.player.setPosition(round(start * 1000) + position)

    def on_position(self, position: int) -> None:
        if self.current_id is None:
            return
        clip = self.get_clip(self.current_id)
        relative = max(0, position - round(clip["start"] * 1000))
        if not self.seek.isSliderDown():
            self.seek.setValue(relative)
        self.update_position(relative, self.seek.maximum())
        if self.preview_end and position >= self.preview_end:
            self.preview_end = 0
            self.player.pause()

    def update_position(self, current: int, total: int) -> None:
        def clock(ms: int) -> str:
            seconds = max(0, ms // 1000)
            return f"{seconds // 60:02d}:{seconds % 60:02d}"
        self.position_label.setText(f"{clock(current)} / {clock(total)}")

    def on_player_error(self, error: QMediaPlayer.Error, description: str) -> None:
        if error != QMediaPlayer.Error.NoError:
            self.status.setText(f"Ошибка воспроизведения: {description}")

    def start_export(self) -> None:
        if self.report is None:
            return
        ids = [self.clips.item(i).data(Qt.ItemDataRole.UserRole)
               for i in range(self.clips.count())
               if self.clips.item(i).checkState() == Qt.CheckState.Checked]
        if not ids:
            QMessageBox.information(self, "Выберите фрагменты", "Отметьте фрагменты в списке.")
            return
        output = Path(self.output.text())
        mode = self.subtitle_mode.currentData()
        conflicts = [output / f"clip-{clip_id:02d}.{ext}" for clip_id in ids
                     for ext in ("mp4", "srt") if (output / f"clip-{clip_id:02d}.{ext}").exists()]
        if conflicts:
            QMessageBox.warning(self, "Файлы уже существуют", "Выберите другую папку. Уже существует: " + conflicts[0].name)
            return
        report = self.report
        phrases = [Phrase.from_json(p) for p in report["phrases"]]
        drafts = dict(self.drafts)
        for clip_id in ids:
            if clip_id not in drafts:
                clip = self.get_clip(clip_id)
                drafts[clip_id] = subtitles(phrases, clip["start"], clip["end"])
        if mode != "off":
            for clip_id in ids:
                text = drafts[clip_id].strip()
                if text and not re.search(r"\d{2}:\d{2}:\d{2},\d{3}\s+-->\s+\d{2}:\d{2}:\d{2},\d{3}", text):
                    QMessageBox.warning(self, "Проверьте субтитры", f"В клипе {clip_id} нет корректного таймкода SRT.")
                    return

        def export_selected(emit: Callable[[str], None]) -> list[Path]:
            output.mkdir(parents=True, exist_ok=True)
            results = []
            with tempfile.TemporaryDirectory(dir=output) as temp:
                for number, clip_id in enumerate(ids, 1):
                    emit(f"Экспорт клипа {number} из {len(ids)}")
                    text = drafts[clip_id]
                    subtitle_file = None
                    if mode != "off" and text.strip():
                        subtitle_file = Path(temp) / f"clip-{clip_id}.srt"
                        subtitle_file.write_text(text, encoding="utf-8")
                    clip_mode = mode if text.strip() else "off"
                    try:
                        results.extend(render(report, [clip_id], output, clip_mode == "burn",
                                              subtitle_mode=clip_mode, subtitle_file=subtitle_file))
                    except Exception as error:
                        raise RuntimeError(f"Экспортировано клипов: {len(results)}. Ошибка клипа {clip_id}: {error}") from error
            return results

        self.player.pause()
        self.run_task(export_selected, self.export_complete, "Подготовка экспорта")

    def export_complete(self, paths: list[Path]) -> None:
        if self.subtitle_mode.currentData() != "off":
            for path in paths:
                match = re.fullmatch(r"clip-(\d+)\.mp4", path.name)
                if match:
                    self.edited_ids.discard(int(match.group(1)))
        self.status.setText(f"Готово: {len(paths)} клипов · {self.output.text()}")
        QMessageBox.information(self, "Экспорт завершён", f"Сохранено клипов: {len(paths)}\n{self.output.text()}")

    def run_task(self, task: Callable[[Callable[[str], None]], Any],
                 on_complete: Callable[[Any], None], message: str) -> None:
        self.update_controls(True)
        self.status.setText(message)
        self.progress.setRange(0, 0)
        self.worker = Worker(task)
        self.worker.message.connect(self.on_task_message)
        self.worker.completed.connect(on_complete)
        self.worker.failed.connect(self.task_failed)
        self.worker.finished.connect(self.task_finished)
        self.worker.start()

    def on_task_message(self, message: str) -> None:
        self.status.setText(message)
        match = re.search(r"Распознавание речи:\s*(\d+)%", message)
        if match:
            self.progress.setRange(0, 100)
            self.progress.setValue(min(100, int(match.group(1))))
        elif message.startswith("[") or message.startswith("Используется кэш:"):
            self.progress.setRange(0, 0)

    def task_failed(self, error: str) -> None:
        self.status.setText(f"Ошибка: {error}")
        QMessageBox.critical(self, "Не удалось выполнить операцию", error)

    def task_finished(self) -> None:
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.update_controls(False)

    def update_controls(self, busy: bool) -> None:
        for widget in (self.browse_button, self.open_report_button, self.history, self.select_all_button, self.analyze_button,
                       self.count, self.subtitle_mode, self.language, self.output_button,
                       self.clips, self.editor):
            widget.setEnabled(not busy)
        has_clip = self.report is not None and self.current_id is not None
        self.play_button.setEnabled(not busy and has_clip)
        self.previous_button.setEnabled(not busy and has_clip and self.clips.currentRow() > 0)
        self.next_button.setEnabled(not busy and has_clip and self.clips.currentRow() < self.clips.count() - 1)
        self.seek.setEnabled(not busy and has_clip)
        self.open_srt_button.setEnabled(not busy and has_clip)
        self.export_button.setEnabled(not busy and self.clips.count() > 0)

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "Идёт обработка", "Дождитесь завершения операции перед закрытием окна.")
            event.ignore()
            return
        if not self.confirm_discard():
            event.ignore()
            return
        self.player.stop()
        event.accept()

    def confirm_discard(self) -> bool:
        if not self.edited_ids:
            return True
        answer = QMessageBox.question(
            self, "Несохранённые субтитры",
            "Правки субтитров ещё не экспортированы. Продолжить без их сохранения?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        return answer == QMessageBox.StandardButton.Yes


def main() -> int:
    ffmpeg_dir = PROJECT / ".tools" / "bin"
    if ffmpeg_dir.is_dir():
        os.environ["PATH"] = str(ffmpeg_dir) + os.pathsep + os.environ.get("PATH", "")
    app = QApplication.instance() or QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))
    app.setStyleSheet(STYLE)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
